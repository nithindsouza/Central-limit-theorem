#Q6
 
#Q12

n=100
mean_ = 50
sd_ = 40
se_= sd_ / sqrt(n) # standard error

investigation_p = pnorm(55,50,40) -pnorm(45,50,40)

